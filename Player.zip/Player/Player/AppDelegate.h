//
//  AppDelegate.h
//  Player
//
//  Created by Jeffrey on 2024/12/22.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

