#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>

@interface ViewController () {
    AVAudioSession *audioSession;
}
@property (nonatomic, strong) AVPlayer *player;
@property (nonatomic, strong) AVPlayerItem *playerItem;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    audioSession = [AVAudioSession sharedInstance];
    [self printAudioSession];
    
//    //初始化播放器的时候例如以下设置
//    UInt32 sessionCategory = kAudioSessionCategory_MediaPlayback;
//    AudioSessionSetProperty(kAudioSessionProperty_AudioCategory,
//                            sizeof(sessionCategory),
//                            &sessionCategory);
//    UInt32 audioRouteOverride = kAudioSessionOverrideAudioRoute_Speaker;
//    AudioSessionSetProperty (kAudioSessionProperty_OverrideAudioRoute,
//                             sizeof (audioRouteOverride),
//                             &audioRouteOverride);


    
    NSArray *buttonArr = @[@"扬声器", @"听筒" , @"蓝牙"];
    for (int i = 0; i < buttonArr.count; i++) {
        UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(30 + 80 * i, 200, 70, 34)];
        [self.view addSubview:button];
        button.backgroundColor = [UIColor redColor];
        [button addTarget:self action:@selector(clickChangeStates:) forControlEvents:UIControlEventTouchUpInside];
        button.tag = 100 + i;
    }

    [self playerAudio];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(audioRouteChangeListenerCallback:) name:AVAudioSessionRouteChangeNotification object:nil];
    
    [[UIDevice currentDevice] setProximityMonitoringEnabled:YES]; //建议在播放之前设置yes，播放结束设置NO。这个功能是开启红外感应

    //加入监听
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(sensorStateChange:) name:@"UIDeviceProximityStateDidChangeNotification" object:nil];
}
- (void)getCurrentPlayDeviceLists {
//    CFDictionaryRef currentRouteDescriptionDic = nil;
//    uint32_t dataSize = sizeof(currentRouteDescriptionDic);
//    AudioSessionGetProperty(kAudioSessionProperty_AudioRouteDescription, &dataSize, &currentRouteDescriptionDic);
//    if (currentRouteDescriptionDic){
//        CFArrayRef outputs = CFDictionaryGetValue(currentRouteDescriptionDic, kAudioSession_AudioRouteKey_Outputs);
//        if (outputs && CFArrayGetCount(outputs) > 0) {
//            for (int i = 0; i < CFArrayGetCount(outputs); i++) {
//                CFDictionaryRef output = CFArrayGetValueAtIndex(outputs, i);
//                CFStringRef outputType = CFDictionaryGetValue(output, kAudioSession_AudioRouteKey_Type);
//                NSLog(@"-- -- -- -- --- -- : => %@", outputType);
//            }
//        }
//    }
    
    NSArray *deviceArr = [audioSession.currentRoute outputs];
    for (int i = 0; i < deviceArr.count; i++) {
        NSLog(@"-- -- -- -- --- -- : 当前输出设备：=> %@", deviceArr[i]);
    }
    
}
- (void)clickChangeStates:(UIButton*)sender {
//    [audioSession setActive:NO error:nil];
    if (sender.tag == 100) {
        //设置为公放模式
        [audioSession setCategory:AVAudioSessionCategoryPlayAndRecord withOptions:AVAudioSessionCategoryOptionDuckOthers | AVAudioSessionCategoryOptionDefaultToSpeaker | AVAudioSessionCategoryOptionAllowBluetooth |AVAudioSessionCategoryOptionAllowBluetoothA2DP | AVAudioSessionCategoryOptionMixWithOthers error:nil];
        [audioSession overrideOutputAudioPort:AVAudioSessionPortOverrideSpeaker error:nil];
        NSLog(@"\n\n-- -- -- -- --speaker");
    } else if (sender.tag == 101) {
        [audioSession setCategory:AVAudioSessionCategoryPlayAndRecord withOptions:AVAudioSessionCategoryOptionDuckOthers | AVAudioSessionCategoryOptionMixWithOthers error:nil];
        //设置为听筒模式
        [audioSession overrideOutputAudioPort:AVAudioSessionPortOverrideNone error:nil];
        NSLog(@"\n\n-- -- -- -- --none");
    } else {
        [audioSession setCategory:AVAudioSessionCategoryPlayAndRecord withOptions:AVAudioSessionCategoryOptionAllowBluetooth |AVAudioSessionCategoryOptionAllowBluetoothA2DP  error:nil];
        //设置为听筒模式
        [audioSession overrideOutputAudioPort:AVAudioSessionPortOverrideNone error:nil];
//        NSError *error;
//        [audioSession setMode:AVAudioSessionModeVoiceChat error:&error];
        NSLog(@"\n\n-- -- -- -- --other");
    }
    //让我的App占用听筒或扬声器
    [audioSession setActive:YES error:nil];
}

- (void)playerAudio {
    NSURL *audioURL=[NSURL fileURLWithPath:[[NSBundle mainBundle]pathForResource:@"playerss" ofType:@"mp3"]];
    audioPlayer=[[AVAudioPlayer alloc]initWithContentsOfURL:audioURL error:nil];
    [audioPlayer pause];
    _slider.minimumValue=0.0;
    _slider.maximumValue=audioPlayer.duration;
}

- (IBAction)SliderAudioAction:(UISlider *)sender {
    audioPlayer.currentTime=sender.value;
}

- (IBAction)btnPlayPauseAudio:(UIButton *)sender {
    if (audioPlayer.isPlaying) {
        [audioPlayer pause];
        
    }else{
        [audioPlayer play];
        [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateAudioProgressView) userInfo:nil repeats:true];
    }
}
-(void)updateAudioProgressView{
    _slider.value=audioPlayer.currentTime;
}

- (void)printAudioSession {
    NSLog(@"-- -- -- -- %@    %@  %lu", audioSession.category, audioSession.mode, audioSession.categoryOptions);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self printAudioSession];
    });
}
- (void)audioRouteChangeListenerCallback:(NSNotification*)notification {
    NSDictionary *interuptionDict = notification.userInfo;

       NSInteger routeChangeReason = [[interuptionDict valueForKey:AVAudioSessionRouteChangeReasonKey] integerValue];

       switch (routeChangeReason) {
           case AVAudioSessionRouteChangeReasonNewDeviceAvailable:{
               NSLog(@"headset input");
               break;
           }
           case AVAudioSessionRouteChangeReasonOldDeviceUnavailable:{
               NSLog(@"pause play when headset output");
               break;
           }
           case AVAudioSessionRouteChangeReasonCategoryChange:
               NSLog(@"AVAudioSessionRouteChangeReasonCategoryChange");
               break;
       }
    NSArray *ideveArr = @[@"", @"新设备", @"旧设备", @"类别 变更", @"覆盖", @"" , @"唤醒", @"没找到", @"配置变更"];
    AVAudioSessionRouteDescription *description = interuptionDict[@"AVAudioSessionRouteChangePreviousRouteKey"];
    NSLog(@"-- -- -- -- %@(%@) =>input:%d  %@ output:%@", interuptionDict[@"AVAudioSessionRouteChangeReasonKey"], ideveArr[routeChangeReason],description.inputs.count, description.inputs, description.outputs);
    [self getCurrentPlayDeviceLists];
}
//处理监听触发事件

-(void)sensorStateChange:(NSNotificationCenter *)notification {
    //假设此时手机靠近面部放在耳朵旁，那么声音将通过听筒输出。并将屏幕变暗（省电啊）
    if ([[UIDevice currentDevice] proximityState] == YES){
        NSLog(@"Device is close to user");
        [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
    }else{
        NSLog(@"Device is not close to user");
        [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:nil];
    }

}
@end

/*
 NSError *error = nil;

 // 设置音频会话类别为播放和录音
 [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord error:&error];

 if (error) {
     NSLog(@"Error setting audio session category: %@", error);
 }

 // 激活蓝牙听筒（Handset）模式
 [[AVAudioSession sharedInstance] setMode:AVAudioSessionModeVoiceChat error:&error];

 if (error) {
     NSLog(@"Error setting audio session mode: %@", error);
 }

 // 激活音频会话
 error = nil;
 if (![[AVAudioSession sharedInstance] setActive:YES error:&error]) {
     NSLog(@"Error activating audio session: %@", error);
 }

 */
