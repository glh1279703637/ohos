//
//  ViewController.h
//  Player
//
//  Created by Jeffrey on 2024/12/22.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface ViewController : UIViewController
{
    AVAudioPlayer *audioPlayer;
    BOOL isPlay;
    NSTimer *playbackTimer;
}
@property (weak, nonatomic) IBOutlet UISlider *slider;


@end

